/**
 * REVIEW ARTIFACT — 2026-10-04. Proposed contracts, not a shipped implementation.
 * Read alongside SHOW-ENGINE-PLAN.md. No dependencies or executable room effects.
 * All API names below are proposals unless explicitly identified as existing.
 */
export type Json = null | boolean | number | string | Json[] | { [key: string]: Json };
export type Aspect = 'landscape' | 'portrait';
export type Surface = 'host' | 'moderator' | 'output-background' | 'output-foreground';
export type ParticipantId = string;
export type SourceId = string;

// Interpreter inputs are JSON, never JavaScript source. A registry controls functions.
export type Expr =
  | { op: 'literal'; value: Json }
  | { op: 'get'; path: string[] }
  | { op: 'if'; condition: Expr; then: Expr; else: Expr }
  | { op: 'call'; fn: 'eq' | 'not' | 'and' | 'or' | 'add' | 'subtract' | 'multiply' |
      'divide' | 'min' | 'max' | 'clamp' | 'formatClock' | 'formatPercent' | 'concat'; args: Expr[] };
export type Bound = Json | Expr;
export interface Animation {
  id: string;
  durationMs: number;
  iterations: number | 'infinite';
  easing: string;
  keyframes: { offset: number; styles: Record<string, Json> }[];
  playWhen?: Expr;
  clock: 'cosmetic-local' | 'episode';
  anchor?: 'episode-start' | 'segment-entry';
  // Episode animations seek to authoritative elapsed time; pause freezes them.
}
export interface UINode {
  id: string;
  kind: 'element' | 'text' | 'component';
  tag?: string; // Validated HTML/SVG allowlist; no script, iframe, webview, object.
  component?: string;
  text?: Bound;
  props?: Record<string, Bound>;
  attributes?: Record<string, Bound>;
  styles?: Record<string, Bound>;
  variants?: { when: Expr; styles: Record<string, Bound> }[];
  when?: Expr;
  repeat?: { items: Expr; itemName: string; key: Expr };
  children?: UINode[];
  animations?: Animation[];
  events?: Record<string, { action: ShowAction['kind']; payload?: Record<string, Bound> }>;
}
export interface Asset {
  id: string;
  path: string; // Relative package path, never a privileged filesystem/network URL.
  sha256: string;
  mediaType: string;
  bytes: number;
}
export interface Rect {
  x: number; y: number; width: number; height: number; // Normalized to output canvas.
}
export interface SlotPlacement {
  slotId: string;
  rect: Rect;
  fit: 'contain' | 'cover'; // Cover requires verified native crop math.
  z: number;
  visible: boolean | Expr;
  // MVP: rectangular native video, fixed geometry per segment, no CSS slot animation.
}
export interface Layout {
  id: string;
  aspect: Aspect;
  width: number;
  height: number;
  background: UINode;
  foreground: UINode;
  slots: SlotPlacement[];
}
export interface Segment {
  id: string;
  title: string;
  durationMs: number | null;
  clock: 'episode-elapsed'; // Sponsored wall-clock policies are deliberately deferred.
  layouts: Partial<Record<Aspect, string>>;
  next: string | null;
  advance: 'host' | 'timer';
  enter: Array<'open-round-vote' | 'reveal-result' | 'backstage-non-winners'>;
  exit: Array<'close-round-vote'>;
}
// Future native adapter; discover support before changing any live configuration.
export interface NativeOutputSpec {
  outputId: string;
  aspect: Aspect;
  width: number;
  height: number;
  fps: number;
  backend: 'main-canvas' | 'private-obs-canvas';
  sharedCaptureSourceIds: SourceId[];
  audio: 'existing-program-bus'; // Do not sum the same microphones a second time.
}
export interface ShowManifest {
  schema: 'producer.show/1';
  id: string;
  version: string;
  engineRange: string;
  name: string;
  brief: string;
  assets: Asset[];
  components: Record<string, UINode>;
  surfaces: { host: UINode; moderator: UINode };
  layouts: Layout[];
  supportedAspects: Aspect[];
  initialSegment: string;
  segments: Segment[];
  slots: { id: string; purpose: string; required: boolean; media: 'video' }[];
  participantInteractions: { id: string; widget: 'choices' | 'button';
    label: string; action: 'vote.submit' | 'interaction.submit';
    roles: Array<'audience' | 'guest'>; segmentIds: string[];
    choices?: { id: string; label: string }[] }[];
  rules: {
    vote: { choices: string[]; oncePerParticipant: true; allowContestantVotes: boolean;
      tie: 'host-decides'; zeroVotes: 'host-decides' };
    heat: { source: 'accepted-reactions'; windowMs: number; maxPerPrincipalPerSecond: number;
      hotAt: number; decay: 'window-expiry' };
    elimination: 'backstage';
  };
  recording: { default: 'local-auto'; existingManual: 'reuse-with-episode-interval' };
  // No action can grant capabilities, network access, or arbitrary native IPC.
}
export interface SlotBinding {
  slotId: string;
  participantId: ParticipantId;
  sourceId: SourceId;
  expectedSourceRevision: number;
}
export type EpisodeStatus = 'preparing' | 'starting' | 'running' | 'paused' |
  'recovering' | 'stopping' | 'ended' | 'interrupted' | 'failed';
export interface EpisodeClock {
  elapsedMsAtAnchor: number;
  serverAnchorMs: number;
  running: boolean;
  // Client estimates server offset; uses monotonic time between anchors.
  // The controller, not a browser timer, decides deadlines/segment progression.
}
export interface EpisodeSnapshot {
  episodeId: string;
  roomId: string;
  showId: string;
  showVersion: string;
  manifestHash: string;
  status: EpisodeStatus;
  revision: number;
  publisherEpoch: number;
  segmentId: string;
  clock: EpisodeClock;
  bindings: SlotBinding[];
  participants: Record<ParticipantId, {
    competition: 'competing' | 'eliminated' | 'winner' | 'none';
    stage: 'audience' | 'backstage' | 'onstage';
    mediaConnected: boolean;
    audienceInteractionsAllowed: boolean;
  }>;
  scores: Record<ParticipantId, number>;
  vote: { interactionId: string; episodeId: string; status: 'open' | 'closed' | 'revealed';
    tally: Record<string, number>; version: number } | null;
  heat: { value: number; serverAnchorMs: number; version: number };
  result: { winnerSlotId: string | null; reason: 'votes' | 'host-tiebreak' | 'host-zero-votes' | null };
  transition: { commandId: string; targetSegmentId: string; status: 'applying' | 'failed' } | null;
  recording: RecordingReceipt | null;
}
export interface RecordingReceipt {
  recordingId: string;
  outputId: string;
  ownership: 'episode' | 'pre-existing-manual';
  status: 'recording' | 'finalizing' | 'ready' | 'interrupted' | 'failed';
  episodeStartOffsetMs: number;
  episodeEndOffsetMs: number | null;
  // Raw local path stays local; metadata sync does not upload video.
}
export type ShowAction =
  | { kind: 'episode.start'; aspect: Aspect; record: boolean }
  | { kind: 'episode.pause' }
  | { kind: 'episode.resume' }
  | { kind: 'episode.stop' }
  | { kind: 'segment.advance'; segmentId: string }
  | { kind: 'score.award'; participantId: string; delta: number; reason: string }
  | { kind: 'result.resolve'; winnerSlotId: string; reason: string }
  | { kind: 'vote.submit'; interactionId: string; choiceId: string }
  | { kind: 'interaction.submit'; interactionId: string; actionId: string; value: Json }
  | { kind: 'reaction.submit'; reaction: string }
  | { kind: 'hand.raise'; raised: boolean }
  | { kind: 'chat.send'; text: string };
export interface CommandEnvelope {
  commandId: string;
  roomId: string;
  episodeId: string;
  expectedEpisodeRevision: number;
  action: ShowAction;
  // Principal, grants, epoch, sequence and deadlines come from authenticated authority.
  // Clients never self-assert a role or authority epoch.
}
export interface NativeShowTransaction {
  commandId: string;
  roomId: string;
  episodeId: string;
  manifestHash: string;
  publisherEpoch: number;
  expectedNativeGeneration: number;
  expectedBindingsRevision: number;
  sequence: number;
  expiresAtServerMs: number;
  outputId: string;
  targetSegmentId: string;
  sourceChanges: { id: SourceId; expectedRevision: number; rect: Rect;
    visible: boolean; muted?: boolean; z: number; fit: 'contain' | 'cover' }[];
  overlayStateRevision: number;
}
export interface AppliedReceipt {
  commandId: string;
  status: 'applied' | 'failed' | 'expired';
  publisherEpoch: number;
  nativeGeneration: number;
  actualSources: { id: string; revision: number; visible: boolean; muted: boolean }[];
  overlayStateRevision: number;
  error?: string;
}

export const reviewPlan = {
  status: 'plan-only-awaiting-review',
  chosenByUser: {
    prototype: 'Two contestants, audience vote, heat effect and winner reveal',
    nordcraft: 'Adapt selected open-source modules behind our stable schema',
    customUI: 'Producer host/mod workspace and show output',
    ios: 'Native audience UI with existing vote/chat/reaction controls',
    guests: 'Keep audience interaction powers before, during and after stage participation',
  },
  principles: [
    'Room is the venue; Show is the reusable definition; Episode is one run.',
    'Keep composition, animation, recording and encoding on host hardware.',
    'Reuse existing backend, Durable Objects, control link and interaction services.',
    'No new Cloudflare product or required rented media server.',
    'The runtime builds once; ordinary show packages are interpreted JSON and assets.',
    'Show mode has its own UI; Producer owns always-accessible Stop and Studio controls.',
    'A segment may select a scene, but timeline/competition state is not the scene state.',
    'Never confuse accepted controller intent with applied native source/output state.',
    'Stage/visibility/mute/competition membership/interaction rights are independent.',
    'A show does not automatically start or stop external streams.',
  ],
  currentEvidence: [
    { path: 'src-tauri/src/live/engine.rs', fact: 'reset_video derives width from height * 16 / 9.' },
    { path: 'src-tauri/src/live/graph.rs', fact: 'apply_scene prevalidates and uses obs_scene_atomic_update; audio mute is applied in the batch, but audio is not an OBS video-frame transaction.' },
    { path: 'src-tauri/src/live/record.rs', fact: 'One recording output uses obs_get_video; multiple network outputs do not prove multiple aspect canvases.' },
    { path: 'src/lib/programCapture.ts', fact: 'Shared program capture and separate conversation audio return exist; output identity/aspect extension is still needed.' },
    { path: 'src/lib/roomControl.ts', fact: 'Existing control socket coordinates scene/actions; extend it rather than opening a rival show authority.' },
    { path: 'server/src/interactionRoutes.ts', fact: 'Guest input.vote and per-device audience identities already exist; principal continuity across promotion needs explicit work.' },
    { path: 'src/lib/roomVotes.ts', fact: 'Historical room votes can be selected; show state must select by episode and interaction ID.' },
    { path: 'src-tauri/src/live/bridge.rs', fact: 'Loopback overlay bridge exists, but current overlay templates are not a generic show runtime.' },
    { path: 'src/lib/ipc.ts', fact: 'Studio captures the entire application window; this cannot become the show-output renderer.' },
    { path: 'boomin-ios/Sources/RoomAudienceView.swift', fact: 'Native audience surface exists; arbitrary JSON HTML does not become SwiftUI.' },
  ],
  nordcraft: {
    upstream: 'https://github.com/nordcraftengine/nordcraft',
    inspectedCommit: 'e4ebe92c42f6c4226ad7d0bb33a70ff7206178c8',
    borrowCandidates: ['Formula evaluator subset', 'JSON CSS/keyframe generation', 'Reactive signals and keyed node updates'],
    boundary: 'Vendor audited modules under a thin adapter; our schema and lifecycle are independent.',
    proof: 'Local source checks verified JSON formulas and keyframe generation only; full OBS renderer remains a spike.',
    obligations: ['Retain applicable Apache-2.0 license/NOTICE and copyright', 'Mark modifications', 'Audit transitive imports and dependencies'],
    exclude: ['Upstream arbitrary JavaScript handlers', 'Editor new Function path', 'Unrestricted global/network/API context'],
  },
  verticalCanvasResearch: {
    package: '/Users/klevelandbishop/Downloads/vertical-canvas-macos-universal.pkg',
    inspectedOnly: true,
    packageVersion: '1.6.4',
    sha256: '281348c4de542f56f0737fbdd70a9fbb644dd40d14e04acbbd4914addc9fdd2b',
    upstream: 'https://github.com/Aitum/obs-vertical-canvas',
    matchingSourceCommit: '9cd13b8f3cd9afe01d665a2c869a24e88b9a8555',
    lessons: ['Per-canvas dimensions/video mix', 'Shared source references with independent scene items/layout', 'Encoder binds to canvas-specific video output', 'Canvas-local lifecycle instead of global reset for second output'],
    producerObs: '32.1.2, commit fb4d98bf88fae5fc85cb11fc57f7c5e309282194',
    candidateAPIs: ['obs_canvas_create_private', 'obs_canvas_scene_create', 'obs_canvas_set_channel', 'obs_canvas_reset_video', 'obs_canvas_get_video', 'obs_view_add2 as alternative lower-level mix path'],
    evidence: 'Pinned OBS headers and exported symbols in the local signed dev engine both contain these APIs.',
    integration: 'Use libobs directly in a Qt-free native adapter; do not load the OBS frontend/Qt plugin.',
    audio: 'Additional canvas flags must not duplicate shared microphones in public audio; retain one processed program bus.',
    license: 'Aitum contains GPL v2 license text; verify exact applicable license before copying code. No plugin code is vendored by this plan.',
    uncertainty: 'API availability is verified; multi-canvas browser render/capture/recording and cleanup still require P0b.',
  },
  guestInteractionContract: {
    roles: ['audience', 'guest-backstage', 'guest-onstage', 'moderator', 'host'],
    sharedAudiencePowers: ['Read/send permitted chat', 'Vote', 'React', 'Use declared participant interaction actions'],
    mediaPowers: 'Separate grants for camera, microphone and screen; UI actions never silently enable capture.',
    controlPowers: 'Separate room/show grants for scenes, admission, voting lifecycle and results.',
    identity: 'Carry a verified room interaction principal from audience to guest; one participant is counted once.',
    directGuest: 'Guest invitation exchanges into the same interaction capability family; existing input.vote must be preserved.',
    handoff: 'Backend links identities using an authenticated single-use promotion exchange, never by a client-claimed ID or leaked invite code.',
    dedupe: 'Vote identity, cooldowns and moderation restrictions survive promotion, demotion, reload and reconnect.',
    limits: 'Anonymous per-device identity cannot guarantee one human across unrelated devices; do not claim that.',
    policy: 'Contestants may vote once, including for themselves in the test; show rules may explicitly exclude contestants.',
    elimination: 'Move the losing competitor backstage after native confirmation; retain interaction rights and guest connection.',
    privacy: 'Guests receive their own capabilities and public state, not privileged host/mod control data.',
    customClicks: 'Declarative participant controls map to registered interaction schemas; generic submit validates bounded values/rate/grants server-side. Native clients render supported standard widgets.',
    clients: ['Guest web page: persistent interaction controls beside return feed', 'Native iOS audience: preserve identity and interactions across stage invitation', 'Guest media page: receives the same interaction identity; no arbitrary show HTML inside native iOS'],
  },
  runtime: {
    language: 'Validated element/text/component trees, conditional/keyed repetition, formulas, CSS/SVG and keyframes.',
    build: 'Compile the reusable runtime once. Parse/validate/generate bounded CSS when importing JSON.',
    state: 'Dependency-based updates; one immutable episode snapshot plus bounded local UI state.',
    actions: 'Host-owned adapter receives declarative intents, validates surface/grants, submits authenticated commands.',
    layers: 'Background browser source below native video; foreground browser source above video. Both consume one state revision/clock.',
    nativeSlots: 'Named source bindings translated to normalized rectangles then exact native canvas coordinates.',
    restrictions: 'MVP fixed rectangular source slots per segment; animated native slots, arbitrary video masks and interleaved DOM/video depth are capability-gated.',
    unsupported: 'Reject unsupported requested visual/native features at import/preflight with a node/segment diagnostic; never silently render the wrong geometry.',
    preview: 'Use mock/source placeholders and deterministic recorded event fixtures; edits affect preview only.',
    pinning: 'Episode pins manifest hash, assets and runtime version; an agent edit makes a new package version.',
  },
  isolation: {
    document: 'Imported content never runs in the authenticated Tauri origin or receives its global IPC bridge.',
    renderer: 'Sandboxed host/mod frame plus read-only local OBS browser-source renderer; distinct scoped bridge capabilities.',
    loopback: 'Bind loopback only; require unpredictable per-session resource capabilities, validate Origin/Host where available, deny foreign write requests.',
    bridge: 'Validate message source/window/origin/session and schema; no arbitrary IPC method forwarding. Sandbox isolation must pass real Tauri/CEF tests.',
    assets: 'Import JSON plus local asset directory; copy validated assets to managed package storage. Archive transport can follow.',
    validation: ['JSON Schema + semantic validation', 'No prototype pollution paths', 'No cycles in component graph', 'Finite geometry and bounded expression work', 'URL/CSS/attribute allowlists and CSP', 'Bounded files/nodes/repeat expansion/keyframes', 'Hash/size/MIME verification', 'No raw HTML/JS or privileged network calls'],
    proposedBudgets: { manifestBytes: 2_000_000, assetBytes: 50_000_000, nodesPerSurface: 2000, depth: 64, repeatedNodes: 2000, actionsPerSecond: 10 },
    budgetsNote: 'Initial review defaults; measure real memory/render cost and tune without relaxing trust boundaries.',
  },
  authority: {
    owner: 'Existing room controller, with the same protocol in hosted and self-hosted deployments.',
    actions: 'Deduplicated commandId, expected episode revision, authenticated principal, current publisher epoch, bounded queue and deadline.',
    persistence: 'Persist episode transition intent and effect outbox before sending; native receipt advances committed state.',
    outbox: 'Idempotent interaction create/close/reveal and native effects have separate receipts; crash/retry reconciles them.',
    atomicity: 'One controller commit is atomic; there is no distributed transaction spanning native OBS, browser paint and the vote service.',
    starting: 'Prepare sources/renderer/recording locally, persist starting intent, apply native layout, verify receipts, then commit running clock.',
    advancing: 'Close/freeze vote at authority deadline, save result, issue source/layout transition, expose applying state; commit target segment after native receipt.',
    failure: 'Pause in recovering on missing/failed receipt; snapshot actual native state, do not fake success or replay an expired stage action.',
    nativeGuard: 'Check epoch/generation/sequence/deadline on engine thread immediately before apply, not only before IPC enqueue.',
    audioGuard: 'Apply mute safely with stage transitions; test a fail-closed gate so an eliminated mic cannot remain public on partial failure.',
    timers: 'Persist deadline/clock anchors; use existing DO alarm mechanism for deadlines, never rely on host UI setTimeout for shared state.',
    highRate: 'Coalesce accepted audience aggregates; local CSS owns frames. No animation-frame events in DO or action log.',
    hostLoss: 'Publisher lease expiry freezes progression, closes vote inputs at the freeze boundary, retains episode as recovering.',
    reconnect: 'Recover same episode/hash/epoch with new lease; host explicitly resumes after output/recording reconciliation.',
    moderator: 'May operate only delegated show controls; cannot become publisher or grant themselves authority.',
  },
  data: {
    existing: ['Room identity and branded entrances', 'Current live run ledger', 'Interaction envelope/tally storage', 'Local recording catalogue'],
    proposed: [
      'Show definitions: owner, show/version, immutable manifest+asset hashes and engine range',
      'Room show attachment: pinned definition reference + validated room bindings/overrides',
      'Episodes: room/show hash, lifecycle/clock, segment, roster/results, revision and recording association',
      'Episode action log/outbox: idempotency keys, principal reference, outcomes and recovery checkpoints',
      'Interaction episode_id: additive linkage; do not overload existing external-stream run_id',
      'Recording episode/output association: local ownership plus recording intervals and safe metadata sync',
    ],
    episodeAndRun: 'An episode may coexist with the existing external stream run; starting/stopping either must not terminate the other.',
    noFrameLog: 'Store decisions, transition receipts and checkpoints; aggregate reactions with bounded retention, not every rendered frame.',
    metadata: 'No guest personal details or local filesystem path required in audience snapshots.',
  },
  recording: {
    default: 'Local auto-record shown before Start; explicit unrecorded override is allowed and logged.',
    startFailure: 'Do not mark the episode running if required recording fails; report disk/encoder error and offer retry or explicit unrecorded start.',
    manualAlreadyRunning: 'Reuse without taking ownership; record episode interval offsets. Stop show must not stop the manual recorder.',
    owned: 'Stop/finalize only the episode-owned recording; verify output stopped, file exists and catalogue state before calling it ready.',
    interrupted: 'Recovery reads catalogue/file state; failed finalization is interrupted/failed, never a silently successful recording.',
    restore: 'Restore show-owned room geometry with revision checks; do not overwrite host manual changes. End retains normal room media/session.',
    outputs: 'MVP one landscape recording; future active formats each get a distinct file/output ID under the same episode.',
    streaming: 'Preserve ongoing external output; first show must match existing canvas configuration, not reset it while live.',
  },
  formatGates: [
    { phase: 'MVP', support: 'One landscape output at the current compatible video mode', gate: 'Full JSON render + native source composition + capture + local recording on Mac and Windows' },
    { phase: 'Portrait', support: 'One explicitly selected portrait output', gate: 'Explicit width/height config throughout engine, preview, geometry, captures, recordings and destination routing; safe mode change while idle' },
    { phase: 'Both', support: 'Concurrent landscape and portrait', gate: 'Proven independent compositors/output identities and encoders sharing captures; never reset global obs_get_video underneath another output' },
  ],
  rollout: {
    featureFlag: 'show_engine_v1 (proposed), off until rehearsal gates pass',
    installation: 'No forced restart, network migration or show-start action as part of this review artifact.',
    compatibility: 'Ordinary rooms, moderator sources, existing links, conversations, voting and native iOS remain usable without loading a show.',
    shipping: 'Separate reviewable changes per phase; no release-number change or deployment implicitly included in writing this plan.',
  },
} as const;

// Actual JSON-compatible fixture, not just a named preset. Full styles/components are
// authorable; these two contestant frames do not limit future formats to this design.
const get = (...path: string[]): Expr => ({ op: 'get', path });
const lit = (value: Json): Expr => ({ op: 'literal', value });
const eq = (a: Expr, b: Expr): Expr => ({ op: 'call', fn: 'eq', args: [a, b] });
const button = (id: string, text: string, action: ShowAction['kind'], payload?: Record<string, Bound>): UINode => ({
  id, kind: 'element', tag: 'button', attributes: {
    type: 'button', disabled: { op: 'call', fn: 'not', args: [get('capabilities', 'actions', action)] },
  },
  styles: { padding: '12px 18px', borderRadius: '12px', background: '#a8ffce', color: '#07121a', fontWeight: 700 },
  events: { click: { action, ...(payload ? { payload } : {}) } },
  children: [{ id: `${id}-label`, kind: 'text', text }],
});
export const testShow: ShowManifest = {
  schema: 'producer.show/1', id: 'producer.two-contestant-test', version: '0.1.0',
  engineRange: '>=0.1.0 <0.2.0', name: 'Head to Head',
  brief: 'Two contestants get a timed round. Everyone with voting rights, including guests, can choose a winner. Reactions heat the visuals. The host resolves ties.',
  assets: [], components: {}, supportedAspects: ['landscape'],
  recording: { default: 'local-auto', existingManual: 'reuse-with-episode-interval' },
  slots: [
    { id: 'left', purpose: 'Contestant A camera', required: true, media: 'video' },
    { id: 'right', purpose: 'Contestant B camera', required: true, media: 'video' },
  ],
  participantInteractions: [{
    id: 'round-vote', widget: 'choices', label: 'Who wins this round?',
    action: 'vote.submit', roles: ['audience', 'guest'], segmentIds: ['round'],
    choices: [{ id: 'left', label: 'Contestant A' }, { id: 'right', label: 'Contestant B' }],
  }],
  rules: {
    vote: { choices: ['left', 'right'], oncePerParticipant: true, allowContestantVotes: true, tie: 'host-decides', zeroVotes: 'host-decides' },
    heat: { source: 'accepted-reactions', windowMs: 10_000, maxPerPrincipalPerSecond: 1, hotAt: 10, decay: 'window-expiry' },
    elimination: 'backstage',
  },
  initialSegment: 'intro',
  segments: [
    { id: 'intro', title: 'Meet the contestants', durationMs: null, clock: 'episode-elapsed', layouts: { landscape: 'duel' }, next: 'round', advance: 'host', enter: [], exit: [] },
    { id: 'round', title: 'Audience round', durationMs: 60_000, clock: 'episode-elapsed', layouts: { landscape: 'duel' }, next: 'reveal', advance: 'timer', enter: ['open-round-vote'], exit: ['close-round-vote'] },
    { id: 'reveal', title: 'Winner', durationMs: null, clock: 'episode-elapsed', layouts: { landscape: 'winner' }, next: 'outro', advance: 'host', enter: ['reveal-result', 'backstage-non-winners'], exit: [] },
    { id: 'outro', title: 'Thanks for watching', durationMs: null, clock: 'episode-elapsed', layouts: { landscape: 'winner' }, next: null, advance: 'host', enter: [], exit: [] },
  ],
  surfaces: {
    host: { id: 'host-desk', kind: 'element', tag: 'main', styles: { display: 'grid', gap: '16px', padding: '24px', background: '#07121a', color: '#ffffff' }, children: [
      { id: 'host-title', kind: 'text', text: 'Head to Head — Control desk' },
      { id: 'host-clock', kind: 'text', text: { op: 'call', fn: 'formatClock', args: [get('derived', 'segmentRemainingMs')] } },
      { ...button('begin-round', 'Start audience round', 'segment.advance', { segmentId: 'round' }), when: eq(get('episode', 'segmentId'), lit('intro')) },
      { ...button('pause', 'Pause', 'episode.pause'), when: eq(get('episode', 'status'), lit('running')) },
      { ...button('resume', 'Resume', 'episode.resume'), when: eq(get('episode', 'status'), lit('paused')) },
      { ...button('resolve-left', 'Choose contestant A', 'result.resolve', { winnerSlotId: 'left', reason: 'Host resolves tie or no votes' }), when: get('derived', 'needsWinnerDecision') },
      { ...button('resolve-right', 'Choose contestant B', 'result.resolve', { winnerSlotId: 'right', reason: 'Host resolves tie or no votes' }), when: get('derived', 'needsWinnerDecision') },
      { ...button('outro', 'Finish reveal', 'segment.advance', { segmentId: 'outro' }), when: eq(get('episode', 'segmentId'), lit('reveal')) },
    ] },
    moderator: { id: 'mod-desk', kind: 'element', tag: 'main', styles: { padding: '20px', background: '#07121a', color: '#ffffff' }, children: [
      { id: 'mod-title', kind: 'text', text: 'Head to Head — Moderator desk' },
      { id: 'mod-status', kind: 'text', text: get('episode', 'segmentId') },
      button('mod-pause', 'Pause round', 'episode.pause'),
    ] },
  },
  layouts: ['duel', 'winner'].map((id): Layout => ({
    id, aspect: 'landscape', width: 1280, height: 720,
    slots: id === 'duel'
      ? [
          { slotId: 'left', rect: { x: .04, y: .19, width: .44, height: .65 }, z: 10, visible: true, fit: 'contain' },
          { slotId: 'right', rect: { x: .52, y: .19, width: .44, height: .65 }, z: 11, visible: true, fit: 'contain' },
        ]
      : ['left', 'right'].map((slotId): SlotPlacement => ({
          slotId, rect: { x: .22, y: .19, width: .56, height: .65 }, z: 10,
          visible: eq(get('episode', 'result', 'winnerSlotId'), lit(slotId)), fit: 'contain',
        })),
    background: { id: `${id}-background`, kind: 'element', tag: 'div', styles: { position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at top, #21396b, #07121a 75%)' } },
    foreground: { id: `${id}-foreground`, kind: 'element', tag: 'div', styles: { position: 'absolute', inset: 0, color: '#ffffff', fontFamily: 'sans-serif' }, children: [
      { id: `${id}-title`, kind: 'element', tag: 'h1', styles: { position: 'absolute', left: '4%', top: '2%', margin: 0, fontSize: '48px' }, children: [{ id: `${id}-title-text`, kind: 'text', text: 'HEAD TO HEAD' }] },
      { id: `${id}-clock`, kind: 'element', tag: 'div', when: eq(get('episode', 'segmentId'), lit('round')), styles: { position: 'absolute', right: '4%', top: '4%', fontSize: '42px', fontVariantNumeric: 'tabular-nums' }, children: [{ id: `${id}-clock-text`, kind: 'text', text: { op: 'call', fn: 'formatClock', args: [get('derived', 'segmentRemainingMs')] } }] },
      { id: `${id}-heat`, kind: 'element', tag: 'div', when: get('derived', 'hot'), styles: { position: 'absolute', inset: '1%', border: '8px solid #ff793e', borderRadius: '24px', boxShadow: '0 0 40px #ff793e' }, animations: [{ id: `${id}-pulse`, durationMs: 800, iterations: 'infinite', easing: 'ease-in-out', clock: 'cosmetic-local', keyframes: [{ offset: 0, styles: { opacity: .45 } }, { offset: .5, styles: { opacity: 1 } }, { offset: 1, styles: { opacity: .45 } }] }] },
      { id: `${id}-result`, kind: 'element', tag: 'div', when: { op: 'call', fn: 'or', args: [eq(get('episode', 'segmentId'), lit('reveal')), eq(get('episode', 'segmentId'), lit('outro'))] }, styles: { position: 'absolute', bottom: '5%', left: '4%', fontSize: '48px', fontWeight: 800 }, children: [{ id: `${id}-winner-name`, kind: 'text', text: { op: 'call', fn: 'concat', args: [lit('WINNER: '), get('derived', 'winnerDisplayName')] } }], animations: [{ id: `${id}-reveal`, durationMs: 900, iterations: 1, easing: 'ease-out', clock: 'episode', anchor: 'segment-entry', keyframes: [{ offset: 0, styles: { opacity: 0, transform: 'translateY(30px)' } }, { offset: 1, styles: { opacity: 1, transform: 'translateY(0px)' } }] }] },
    ] },
  })),
};

export const implementationPhases = [
  {
    id: 'P0', title: 'Freeze contracts and prove the renderer boundary',
    changes: ['Validate the schema/fixture; adapt selected Nordcraft modules', 'Render an expressive JSON composition in actual OBS browser source on Mac and Windows', 'Prove alpha, fonts, keyed updates, countdown/heat animation and sandbox action channel'],
    files: ['NEW shared/show/schema.ts', 'NEW shared/show/validate.ts', 'NEW src/features/shows/runtime/', 'NEW src/features/shows/nordcraft-adapter/', 'src-tauri/src/live/bridge.rs'],
    pass: ['Unsupported geometry/action rejected before load', 'No Tauri/filesystem/token access from imported node tree', 'Background/native videos/foreground order proven in recording, not only web preview'],
    stopIf: 'If isolated rendering or video-layer synchronization fails, revise renderer boundary before implementing authority/UI.',
  },
  {
    id: 'P0b', title: 'Early vertical/multi-canvas native spike informed by Aitum',
    changes: ['Create a private portrait canvas with libobs directly; do not modify main canvas mode', 'Add existing camera/guest source references with independent scene-item geometry', 'Attach encoder/recording to canvas-specific video, keep processed audio once', 'Test browser overlay, view capture, simultaneous stop/cleanup and main-output continuity'],
    files: ['NEW disposable native output spike harness', 'src-tauri/src/live/ffi.rs', 'src-tauri/src/live/engine.rs', 'src-tauri/src/live/graph.rs', 'src-tauri/src/live/record.rs'],
    pass: ['Actual exported APIs on Mac and Windows engine artifacts', 'Two distinct aspect recordings from shared capture', 'No doubled audio, global reset or capture/peer duplication', 'Stopping secondary canvas leaves main output running'],
    stopIf: 'Do not promise Both or port the Qt plugin if the Qt-free compositor/browser/output spike fails; retain landscape MVP and revise adapter.',
  },
  {
    id: 'P1', title: 'Episode authority, interaction identity and recovery contracts',
    changes: ['Add immutable definitions/room attachment/episode/outbox persistence', 'Extend existing socket and hosted/self-hosted controller with show commands/snapshots/receipts', 'Add episode-scoped votes and verified audience-to-guest principal handoff', 'Implement clock/pause/tie/zero-vote/recovery reducer'],
    files: ['NEW shared/show/protocol.ts', 'NEW shared/show/reducer.ts', 'server/src/roomstate.ts', 'server/src/realtime.ts', 'server/src/roomCommands.ts', 'server/src/roomActions.ts', 'server/src/interactionRoutes.ts', 'Hosted backend corresponding realtime/migration files in its own repository', 'src/lib/boominRoom.ts', 'src/lib/roomControl.ts'],
    pass: ['Repeated start/advance/reveal command has one effect', 'Old episode vote never appears', 'Duplicate/misordered receipt and stale epoch cannot progress episode', 'Guest stage switch does not add a vote/connection identity or reset cooldown'],
  },
  {
    id: 'P2', title: 'Native show source and recording adapter',
    changes: ['Map slots to existing camera/guest sources; validated native batch guards', 'Create background/foreground show-owned browser sources; measure visual revision readiness', 'Keep existing processed program audio and mix-minus return', 'Add recording ownership/episode interval/finalization metadata; preserve external streams and baseline room state'],
    files: ['NEW src/lib/showNative.ts', 'src/lib/ipc.ts', 'src/lib/programCapture.ts', 'src-tauri/src/live/graph.rs', 'src-tauri/src/live/engine.rs', 'src-tauri/src/live/commands.rs', 'src-tauri/src/live/bridge.rs', 'src-tauri/src/live/record.rs', 'src-tauri/src/recordings.rs'],
    pass: ['Native snapshot equals committed layout/stage/mute state', 'Record includes actual guest/camera plus overlay; controls are absent', 'Stop show leaves pre-existing manual recording and external stream running', 'Disk failure/start crash/stop timeout reported truthfully'],
  },
  {
    id: 'P3', title: 'Show workspace and guest participation UI',
    changes: ['Room top-bar Show entry/import/source assignment/preflight', 'Isolated JSON host/mod surfaces with capability-aware actions', 'Producer-owned Stop/Studio/recovery/recording status above imported UI', 'Guest web controls for chat/vote/reactions while seeing return feed', 'Native iOS episode fields and continuity across stage invitation'],
    files: ['NEW src/features/shows/ShowWorkspace.tsx', 'NEW src/features/shows/ShowPreflight.tsx', 'src/views/Live.tsx', 'src/views/ModBoard.tsx', 'src/views/ModSeat.tsx', 'server/guest/src/GuestRoomPage.tsx', 'server/guest/src/interactions.ts', 'server/guest/src/AudiencePage.tsx', 'boomin-ios/Sources/AudienceModels.swift', 'boomin-ios/Sources/AudienceRoomStore.swift', 'boomin-ios/Sources/RoomAudienceView.swift'],
    pass: ['Mac/Windows host and mod rights are distinct', 'Guest votes/reactions work before/on/after stage; scroll/buttons remain responsive', 'No imported show HTML replaces native iOS audience UI', 'Stop remains usable with malformed/hung show surface'],
  },
  {
    id: 'P4', title: 'Head to Head end-to-end rehearsal and gated release',
    changes: ['Import test show; assign two sources; start recording/intro', 'Run 60-second vote round; audience and guests interact', 'Reveal winner, backstage loser, retain their connection/interactions', 'Stop to room and inspect file/catalogue; repeat with reconnect and failed native effect'],
    files: ['NEW show integration/reducer/native harnesses', 'NEW docs/shows/REHEARSAL-CHECKLIST.md', 'src/lib/featureFlags.ts', 'Release notes only after gates'],
    pass: ['Actual Mac + Windows OBS/encoder recordings verified', 'Remote phone and web guest get coherent video/audio plus inputs', 'Participant consent/mutes and mix-minus remain intact', 'Ordinary room/mod workflow regression checks pass'],
  },
  {
    id: 'P5', title: 'Portrait support, then independent dual output',
    changes: ['Add explicit width/height/output identity through native graph/capture/recording', 'Design agent-authored portrait layout without crop-only fallback', 'Prove two native composition/encoder outputs sharing source captures before enabling Both', 'Route each destination/recording to explicit output; test hardware load and disconnect isolation'],
    files: ['src-tauri/src/live/engine.rs', 'src-tauri/src/live/graph.rs', 'src-tauri/src/live/multi.rs', 'src-tauri/src/live/record.rs', 'src/lib/programCapture.ts', 'src/lib/ipc.ts', 'Show manifest/capability preflight'],
    pass: ['Portrait pipeline validated first', 'Two correct aspect outputs run together without resetting live global canvas', 'Both disabled on unsupported platforms/hardware configurations'],
  },
] as const;

export const reviewerQuestions = [
  'Does the imported UI isolation hold in actual Tauri host frames AND OBS CEF, including asset URL/CSS paths?',
  'Is adapting audited Nordcraft subsets less costly than a small independent runtime with the same schema? Confirm after P0 evidence.',
  'Are room controller storage and outbox effects durable/atomic under hosted and self-hosted implementations?',
  'How does the native bridge verify lease expiry after network partition without trusting stale queued commands?',
  'Can one state revision reliably synchronize both browser overlay layers with native source changes? Define measured tolerance and recovery.',
  'Can elimination mute fail closed without claiming OBS video lock makes audio atomic?',
  'Does identity handoff preserve guest input.vote while preventing promotion from creating a second audience principal?',
  'Are recording ownership and reuse intervals accurate across stop timeouts/crashes/reconnects?',
  'Does show restoration respect live host overrides and maintain external stream/capture continuity?',
  'Which exact libobs API/output graph can support dual aspect on Mac/Windows? P5 requires a prototype, not a promise.',
] as const;
